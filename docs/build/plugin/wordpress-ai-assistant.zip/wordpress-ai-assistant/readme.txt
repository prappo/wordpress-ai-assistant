=== WordPress AI Assistant ===
Requires at least: 5.9
Tested up to: 6.6
Stable tag: 1.0.0
Requires PHP: 7.2
License: GPLv2 or later

== Description ==

WordPress AI Assistant
