<p align="center">
  <img width="150" src="assets/public/animatedlogo.gif" />
  <h1 align="center">WordPress AI Assistant</h1>
  <div align="center"><a target="_blank" href="https://prappo.github.io/wordpress-ai-assistant/">Click here to Preview</a></div>
</p>

<img src="docs/screenshots/wordpress-assistant-chat.png" />