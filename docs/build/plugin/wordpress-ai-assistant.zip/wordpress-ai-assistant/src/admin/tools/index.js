import { developerInfoTool, DeveloperInfoToolUI } from "./developerinfo";

export const tools = [
    developerInfoTool,
];

export const toolsUI = [
    DeveloperInfoToolUI,
];

