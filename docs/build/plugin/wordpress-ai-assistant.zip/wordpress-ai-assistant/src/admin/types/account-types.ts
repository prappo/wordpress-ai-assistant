export type StepProps = {
  stepCount?: (step: number) => void;
  setProvider?: (provider: string) => void;
};
