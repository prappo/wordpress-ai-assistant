import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Switch } from "@/components/ui/switch";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { toast, Toaster } from "sonner";
import * as TabsPrimitive from "@radix-ui/react-tabs";
import { useTheme } from "@/components/theme-provider";
import {
  Loader2,
  Sun,
  Moon,
  Save,
  Bot,
  Key,
  Settings,
  MessageSquare,
  Trash2,
  Sparkles,
  Monitor
} from "lucide-react";
import * as SelectPrimitive from "@radix-ui/react-select";

declare global {
  interface Window {
    wpAiAssistant: {
      apiUrl: string;
      nonce: string;
    };
  }
}

interface Provider {
  id: string;
  name: string;
  description: string;
  icon: React.ReactNode;
}

interface ApiKeys {
  [key: string]: string;
}

interface AISettings {
  systemPrompt: string;
  enableAgent: boolean;
}

type Theme = 'light' | 'dark' | 'system';

interface Preferences {
  theme: Theme;
}

const providers: Provider[] = [
  {
    id: 'openai',
    name: 'OpenAI',
    description: 'Enter your OpenAI API key to use GPT models',
    icon: (
      <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 16 16" fill="none">
        <path d="M0 8C0 3.58172 3.58172 0 8 0C12.4183 0 16 3.58172 16 8C16 12.4183 12.4183 16 8 16C3.58172 16 0 12.4183 0 8Z" fill="url(#paint0_linear_19540_3517_:r2a:)"></path>
        <path d="M13.1349 6.91143C13.4071 6.0943 13.3134 5.19918 12.878 4.45593C12.2233 3.31593 10.907 2.72943 9.62152 3.00543C9.04965 2.36118 8.22802 1.99481 7.36665 2.00006C6.05265 1.99706 4.88677 2.84306 4.48252 4.09331C3.63839 4.26618 2.90977 4.79456 2.48339 5.54343C1.82377 6.68043 1.97414 8.11368 2.85539 9.08868C2.58314 9.9058 2.67689 10.8009 3.11227 11.5442C3.76702 12.6842 5.08327 13.2707 6.36877 12.9947C6.94027 13.6389 7.76227 14.0053 8.62365 13.9997C9.9384 14.0031 11.1046 13.1563 11.5089 11.9049C12.353 11.7321 13.0816 11.2037 13.508 10.4548C14.1669 9.3178 14.0158 7.88643 13.1349 6.91143ZM8.6244 13.2156C8.09827 13.2163 7.58864 13.0322 7.18477 12.6951C7.20315 12.6853 7.23502 12.6677 7.25565 12.6549L9.64515 11.2749C9.7674 11.2056 9.8424 11.0754 9.84165 10.9348V7.56618L10.8515 8.1493C10.8624 8.15455 10.8695 8.16505 10.871 8.17705V10.9667C10.8695 12.2072 9.8649 13.2129 8.6244 13.2156ZM3.79289 11.1519C3.52927 10.6967 3.43439 10.1631 3.52477 9.64518C3.54239 9.65568 3.57352 9.6748 3.59564 9.68755L5.98514 11.0676C6.10627 11.1384 6.25627 11.1384 6.37777 11.0676L9.2949 9.38305V10.5493C9.29565 10.5613 9.29002 10.5729 9.28065 10.5804L6.86527 11.9751C5.78939 12.5946 4.41502 12.2263 3.79289 11.1519ZM3.16402 5.93605C3.42652 5.48006 3.84089 5.1313 4.33439 4.95018C4.33439 4.97081 4.33327 5.00718 4.33327 5.03268V7.79305C4.33252 7.9333 4.40752 8.06343 4.52939 8.1328L7.44652 9.81693L6.43665 10.4001C6.42652 10.4068 6.41377 10.4079 6.40252 10.4031L3.98677 9.0073C2.91314 8.38555 2.54527 7.01155 3.16402 5.93605ZM11.4613 7.86693L8.54415 6.18243L9.55402 5.59968C9.56415 5.59293 9.5769 5.59181 9.58815 5.59668L12.0039 6.9913C13.0794 7.61268 13.448 8.98855 12.8266 10.0641C12.5638 10.5193 12.1498 10.8681 11.6566 11.0496V8.20668C11.6578 8.06643 11.5828 7.93668 11.4613 7.86693ZM12.4663 6.35418C12.4486 6.34331 12.4175 6.32455 12.3954 6.3118L10.0059 4.93181C9.88477 4.86093 9.73477 4.86093 9.61327 4.93181L6.69615 6.6163V5.45005C6.6954 5.43805 6.70102 5.42643 6.71039 5.41893L9.12577 4.02543C10.2016 3.40481 11.5771 3.77418 12.1974 4.85043C12.4595 5.30493 12.5551 5.83706 12.4663 6.35418ZM6.14714 8.4328L5.13689 7.84968C5.12602 7.84443 5.11889 7.83393 5.11739 7.82193V5.03231C5.11814 3.79031 6.12577 2.78381 7.36777 2.78456C7.89315 2.78456 8.40165 2.96906 8.80552 3.30506C8.78715 3.31481 8.75565 3.33243 8.73465 3.34518L6.34514 4.72518C6.22289 4.79456 6.14789 4.92431 6.14864 5.06493L6.14714 8.4328ZM6.69577 7.25005L7.99515 6.49968L9.29452 7.24968V8.75005L7.99515 9.50005L6.69577 8.75005V7.25005Z" fill="white"></path>
        <defs>
          <linearGradient id="paint0_linear_19540_3517_:r2a:" x1="16" y1="16" x2="0" y2="0" gradientUnits="userSpaceOnUse">
            <stop offset="0.147401" stopColor="#3D0C2C"></stop>
            <stop offset="0.749948" stopColor="#0A163D"></stop>
          </linearGradient>
        </defs>
      </svg>
    ),
  },
  {
    id: 'openrouter',
    name: 'OpenRouter',
    description: 'Enter your OpenRouter API key to access multiple AI models',
    icon: (
      <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 16 16" fill="none">
        <path d="M0 8C0 3.58172 3.58172 0 8 0C12.4183 0 16 3.58172 16 8C16 12.4183 12.4183 16 8 16C3.58172 16 0 12.4183 0 8Z" fill="#4A90E2"/>
        <path d="M8 4C5.79086 4 4 5.79086 4 8C4 10.2091 5.79086 12 8 12C10.2091 12 12 10.2091 12 8C12 5.79086 10.2091 4 8 4ZM8 10.5C6.34315 10.5 5 9.15685 5 7.5C5 5.84315 6.34315 4.5 8 4.5C9.65685 4.5 11 5.84315 11 7.5C11 9.15685 9.65685 10.5 8 10.5Z" fill="white"/>
        <path d="M8 6C7.44772 6 7 6.44772 7 7C7 7.55228 7.44772 8 8 8C8.55228 8 9 7.55228 9 7C9 6.44772 8.55228 6 8 6Z" fill="white"/>
      </svg>
    ),
  },
  {
    id: 'groq',
    name: 'Groq',
    description: 'Enter your Groq API key to use Groq models',
    icon: (
      <svg viewBox="0 32.25 152 55.5" className="h-full w-full">
        <g>
          <path d="M84.848,34.137c-9.798,0-17.769,7.971-17.769,17.77s7.971,17.769,17.769,17.769s17.77-7.971,17.77-17.769 S94.645,34.137,84.848,34.137z M84.848,63.013c-6.124,0-11.106-4.983-11.106-11.106s4.982-11.106,11.106-11.106 c6.124,0,11.106,4.982,11.106,11.106S90.973,63.013,84.848,63.013z" />
          <path d="M60.315,34.206c-0.607-0.068-1.217-0.104-1.827-0.108c-0.304,0-0.595,0.009-0.893,0.014s-0.594,0.033-0.891,0.051 c-1.197,0.094-2.382,0.299-3.541,0.611c-2.329,0.629-4.574,1.723-6.515,3.277c-1.97,1.57-3.548,3.575-4.611,5.859 c-0.53,1.138-0.921,2.336-1.165,3.567c-0.121,0.608-0.21,1.222-0.266,1.84c-0.02,0.307-0.055,0.615-0.059,0.921l-0.011,0.459 l-0.005,0.23v0.19l0.015,5.951l0.015,5.951l0.041,5.95h6.664l0.042-5.95l0.015-5.952l0.015-5.951v-0.182l0.005-0.142l0.008-0.285 c0-0.191,0.028-0.375,0.039-0.564c0.036-0.37,0.091-0.738,0.165-1.102c0.146-0.716,0.374-1.413,0.678-2.077 c0.613-1.332,1.528-2.502,2.673-3.419c1.156-0.932,2.541-1.628,4.038-2.042c0.757-0.207,1.532-0.344,2.314-0.408 c0.198-0.011,0.395-0.03,0.594-0.037c0.199-0.007,0.402-0.013,0.595-0.012c0.383,0,0.76,0.025,1.142,0.06 c1.518,0.153,2.989,0.619,4.318,1.368l3.326-5.776C65.108,35.263,62.753,34.484,60.315,34.206z" />
          <path d="M17.77,34.048C7.971,34.048,0,42.019,0,51.817s7.971,17.77,17.77,17.77h5.844v-6.664H17.77 c-6.124,0-11.106-4.982-11.106-11.106s4.982-11.106,11.106-11.106s11.132,4.982,11.132,11.106l0,0v16.365l0,0 c0,6.084-4.954,11.039-11.023,11.103c-2.904-0.024-5.681-1.191-7.729-3.25l-4.712,4.712c3.266,3.283,7.691,5.151,12.321,5.201 v0.003c0.04,0,0.08,0,0.119,0h0.125v-0.003c9.659-0.131,17.48-8.005,17.525-17.686l0.006-16.881 C35.302,41.785,27.422,34.048,17.77,34.048z" />
          <path d="M124.083,34.137c-9.798,0-17.769,7.971-17.769,17.77s7.971,17.769,17.769,17.769h6.08v-6.663h-6.08 c-6.124,0-11.106-4.983-11.106-11.106s4.982-11.106,11.106-11.106c5.799,0,10.572,4.468,11.062,10.143h-0.01v34.12h6.664V51.907 l0,0C141.797,42.108,133.881,34.137,124.083,34.137z" />
        </g>
      </svg>
    ),
  },
  {
    id: 'anthropic',
    name: 'Anthropic',
    description: 'Enter your Anthropic API key to use Claude models',
    icon: (
      <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 16 16" fill="none">
        <path d="M0 8C0 3.58172 3.58172 0 8 0C12.4183 0 16 3.58172 16 8C16 12.4183 12.4183 16 8 16C3.58172 16 0 12.4183 0 8Z" fill="#C36E51"></path>
        <path d="M4.67681 9.70835L6.7142 8.5651L6.74829 8.46546L6.7142 8.41039H6.61456L6.27368 8.38941L5.10946 8.35795L4.09994 8.31599L3.12188 8.26355L2.8754 8.21111L2.64465 7.90694L2.66825 7.75486L2.8754 7.61588L3.1717 7.64211L3.82723 7.68668L4.81053 7.75486L5.52375 7.79681L6.58047 7.90694H6.74829L6.77189 7.83877L6.7142 7.79681L6.66963 7.75486L5.65224 7.06524L4.55094 6.33628L3.97407 5.91674L3.66204 5.70435L3.50471 5.50507L3.43654 5.06979L3.71973 4.75776L4.09994 4.78398L4.19696 4.8102L4.58241 5.1065L5.40576 5.74368L6.48083 6.53557L6.63816 6.66667L6.70109 6.6221L6.70896 6.59063L6.63816 6.47264L6.05342 5.41592L5.42936 4.34084L5.15141 3.89508L5.07799 3.62762C5.05177 3.51749 5.03342 3.42572 5.03342 3.31297L5.35594 2.87507L5.53424 2.81738L5.96427 2.87507L6.1452 3.0324L6.41266 3.64335L6.84531 4.60568L7.51657 5.91412L7.71323 6.3022L7.81812 6.66143L7.85745 6.77156H7.92563V6.70863L7.98069 5.97181L8.08295 5.06717L8.1826 3.90295L8.21668 3.57518L8.37926 3.18186L8.70178 2.96947L8.9535 3.09008L9.16065 3.38639L9.13181 3.5778L9.00857 4.37755L8.76733 5.63093L8.61 6.47001H8.70178L8.80666 6.36513L9.23145 5.80137L9.94467 4.90984L10.2593 4.55586L10.6264 4.16516L10.8624 3.97899H11.3082L11.6359 4.4667L11.4891 4.97015L11.0302 5.55227L10.65 6.04523L10.1046 6.77942L9.76374 7.36678L9.79521 7.41398L9.87649 7.40611L11.1089 7.1439L11.7749 7.02328L12.5694 6.88693L12.9287 7.05475L12.968 7.22519L12.8264 7.57393L11.9768 7.7837L10.9804 7.98298L9.49628 8.33435L9.47793 8.34746L9.49891 8.37368L10.1676 8.43661L10.4534 8.45234H11.1535L12.4567 8.54936L12.7975 8.77487L13.0021 9.05019L12.968 9.25996L12.4436 9.52742L11.7356 9.3596L10.0836 8.96628L9.51726 8.82469H9.4386V8.87189L9.91058 9.33338L10.7759 10.1148L11.8588 11.1217L11.9139 11.3708L11.7749 11.5674L11.6281 11.5465L10.6762 10.8306L10.3091 10.5081L9.47793 9.80799H9.42286V9.88141L9.61428 10.162L10.6264 11.6828L10.6789 12.1496L10.6054 12.3016L10.3432 12.3934L10.0548 12.341L9.4622 11.5097L8.85124 10.5736L8.35828 9.73457L8.29797 9.76865L8.00691 12.9021L7.87056 13.0621L7.55591 13.1827L7.29369 12.9834L7.15472 12.6609L7.29369 12.0237L7.46151 11.1925L7.59786 10.5317L7.7211 9.71097L7.79452 9.43827L7.78928 9.41991L7.72897 9.42778L7.11014 10.2773L6.1688 11.5491L5.42411 12.3462L5.24581 12.417L4.9364 12.2571L4.96524 11.9712L5.1383 11.7169L6.1688 10.4058L6.79024 9.59297L7.19143 9.12361L7.18881 9.05544H7.16521L4.4277 10.8332L3.93999 10.8962L3.73022 10.6995L3.75644 10.377L3.85608 10.2721L4.67943 9.70572L4.67681 9.70835Z" fill="white" fillOpacity="0.92"></path>
      </svg>
    ),
  },
  {
    id: 'google',
    name: 'Google',
    description: 'Enter your Google API key to use Gemini models',
    icon: (
      <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 16 16" fill="none"> <rect width="16" height="16" rx="8" fill="#F3F3FA"></rect> <path d="M8 14C8 13.17 7.84002 12.39 7.52 11.66C7.21002 10.93 6.785 10.295 6.245 9.755C5.705 9.215 5.07 8.78998 4.34 8.48C3.61 8.15998 2.83 8 2 8C2.83 8 3.61 7.84498 4.34 7.535C5.07 7.21498 5.705 6.785 6.245 6.245C6.785 5.705 7.21002 5.07 7.52 4.34C7.84002 3.61 8 2.83 8 2C8 2.83 8.15502 3.61 8.465 4.34C8.78502 5.07 9.215 5.705 9.755 6.245C10.295 6.785 10.93 7.21498 11.66 7.535C12.39 7.84498 13.17 8 14 8C13.17 8 12.39 8.15998 11.66 8.48C10.93 8.78998 10.295 9.215 9.755 9.755C9.215 10.295 8.78502 10.93 8.465 11.66C8.15502 12.39 8 13.17 8 14Z" fill="url(#paint0_radial_38187_34490_:r1m:)"></path> <defs> <radialGradient id="paint0_radial_38187_34490_:r1m:" cx="0" cy="0" r="1" gradientUnits="userSpaceOnUse" gradientTransform="translate(3.1909 6.87693) rotate(18.6832) scale(12.7725 102.316)"> <stop offset="0.0671246" stopColor="#9168C0"></stop> <stop offset="0.342551" stopColor="#5684D1"></stop> <stop offset="0.672076" stopColor="#1BA1E3"></stop> </radialGradient> </defs> </svg>
    ),
  },
  {
    id: 'deepseek',
    name: 'DeepSeek',
    description: 'Enter your DeepSeek API key to use DeepSeek models',
    icon: (
      <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 16 16" fill="none">
        <rect width="16" height="16" rx="8" fill="#ECF0FF"></rect>
        <path d="M0 8C0 3.58172 3.58172 0 8 0C12.4183 0 16 3.58172 16 8C16 12.4183 12.4183 16 8 16C3.58172 16 0 12.4183 0 8Z" fill="#E0E8FF"></path>
        <path d="M13.946 4.84625C13.8254 4.78739 13.7735 4.89951 13.703 4.9565C13.6792 4.97519 13.6586 4.99948 13.6385 5.02097C13.4624 5.2097 13.2569 5.33303 12.9887 5.31808C12.5958 5.29659 12.2609 5.41992 11.9647 5.72079C11.9016 5.34985 11.6923 5.12841 11.3742 4.9864C11.2075 4.91259 11.0388 4.83877 10.9225 4.67807C10.8407 4.56409 10.8188 4.43702 10.7776 4.31182C10.752 4.23614 10.7258 4.15859 10.6389 4.14551C10.5445 4.13056 10.5076 4.20998 10.4707 4.27631C10.3222 4.54727 10.2652 4.84625 10.2703 5.14897C10.2834 5.82914 10.5707 6.37104 11.1406 6.75694C11.2056 6.80086 11.2224 6.84568 11.2018 6.91016C11.1631 7.04282 11.1168 7.17179 11.0757 7.30444C11.05 7.38949 11.0112 7.40815 10.9206 7.37079C10.6076 7.24 10.3371 7.0466 10.0984 6.81205C9.69293 6.41964 9.32621 5.98614 8.86884 5.64697C8.7614 5.56754 8.65443 5.49374 8.54321 5.42366C8.07651 4.96958 8.60444 4.59679 8.72633 4.55287C8.85434 4.50709 8.77072 4.34825 8.35774 4.35012C7.94524 4.352 7.56733 4.49027 7.08613 4.67434C7.01562 4.70236 6.94181 4.72292 6.86565 4.7388C6.42885 4.65658 5.97526 4.63789 5.50108 4.69115C4.6088 4.79113 3.89591 5.21344 3.37175 5.93471C2.74249 6.80086 2.5944 7.78563 2.77566 8.81337C2.96626 9.8953 3.51798 10.7923 4.36634 11.493C5.24554 12.219 6.25836 12.575 7.41363 12.5067C8.11531 12.4666 8.89687 12.3722 9.77794 11.6257C10.0003 11.7359 10.2334 11.7799 10.6207 11.8135C10.9188 11.8415 11.2056 11.7986 11.4279 11.7527C11.776 11.679 11.7517 11.3566 11.626 11.2968C10.6058 10.8212 10.8295 11.0146 10.6258 10.8586C11.1444 10.2438 11.9259 9.6057 12.2315 7.53899C12.2553 7.37452 12.2347 7.27177 12.2315 7.13816C12.2296 7.05779 12.2478 7.02603 12.3403 7.0167C12.5958 6.98771 12.8439 6.91763 13.0719 6.79153C13.7329 6.42993 13.9992 5.83665 14.0622 5.12468C14.0716 5.0163 14.0604 4.90324 13.946 4.84625ZM8.18587 11.2529C7.19688 10.4746 6.71755 10.2186 6.5195 10.2298C6.33447 10.2401 6.36767 10.4522 6.40828 10.5905C6.45081 10.7269 6.50639 10.8212 6.58442 10.9408C6.63814 11.0202 6.67507 11.1389 6.5307 11.2267C6.2121 11.4248 5.65853 11.1604 5.63236 11.1473C4.98813 10.768 4.44949 10.2662 4.06969 9.58044C3.70344 8.9199 3.49041 8.21167 3.45538 7.4558C3.44603 7.27268 3.49976 7.20819 3.68102 7.17552C3.91973 7.1316 4.1664 7.12227 4.40511 7.15681C5.41418 7.30444 6.27328 7.75664 6.99319 8.47143C7.4043 8.87972 7.71543 9.36651 8.0359 9.84206C8.37645 10.3476 8.74317 10.8287 9.20987 11.223C9.37429 11.3613 9.50603 11.4669 9.6317 11.5444C9.2524 11.5864 8.61889 11.5958 8.18587 11.2529ZM8.65955 8.20048C8.65955 8.11916 8.72447 8.05472 8.80622 8.05472C8.82445 8.05472 8.84128 8.05845 8.85621 8.06405C8.8763 8.07151 8.89501 8.08275 8.9095 8.09954C8.93562 8.1248 8.95059 8.16216 8.95059 8.20048C8.95059 8.28175 8.88568 8.34624 8.80435 8.34624C8.7226 8.34624 8.65955 8.28175 8.65955 8.20048ZM10.1316 8.95726C10.0372 8.99558 9.94283 9.02921 9.85223 9.03294C9.71159 9.0395 9.55789 8.98247 9.47427 8.91244C9.34487 8.80404 9.2524 8.74329 9.21312 8.5527C9.19676 8.47143 9.20614 8.34624 9.22059 8.27429C9.25426 8.11916 9.21685 8.02013 9.10802 7.92953C9.01881 7.85572 8.9062 7.8361 8.78197 7.8361C8.73571 7.8361 8.69318 7.81553 8.66142 7.79869C8.60956 7.77253 8.56703 7.70809 8.6077 7.62868C8.62075 7.60342 8.68385 7.54085 8.69878 7.52961C8.86697 7.43341 9.06129 7.46517 9.24116 7.53712C9.40792 7.60529 9.53359 7.73048 9.71484 7.90709C9.90031 8.12107 9.9335 8.18087 10.0391 8.34059C10.1222 8.46674 10.1984 8.59566 10.2502 8.74329C10.2815 8.83485 10.2409 8.91053 10.1316 8.95726Z" fill="#4D6BFE"></path>
      </svg>
    ),
  },
];

const SettingsPage: React.FC = () => {
  const [isSaving, setIsSaving] = useState(false);
  const [isLoading, setIsLoading] = useState(true);
  const [apiKeys, setApiKeys] = useState<ApiKeys>({});
  const [aiSettings, setAISettings] = useState<AISettings>({
    systemPrompt: 'You are a helpful AI assistant.',
    enableAgent: true,
  });
  const [preferences, setPreferences] = useState<Preferences>({
    theme: 'system' as Theme,
  });
  const { theme: currentTheme, setTheme } = useTheme();

  useEffect(() => {
    fetchSettings();
  }, []);

  const fetchSettings = async () => {
    try {
      const baseUrl = window.wpAiAssistant.apiUrl.replace(/\/$/, ''); // Remove trailing slash if exists
      const response = await fetch(`${baseUrl}/wp-ai-assistant/v1/settings/get`, {
        headers: {
          'X-WP-Nonce': window.wpAiAssistant.nonce
        }
      });
      if (!response.ok) {
        throw new Error('Failed to fetch settings');
      }
      const data = await response.json();
      
      // Update state with fetched data
      if (data.apiKeys) setApiKeys(data.apiKeys);
      if (data.aiSettings) setAISettings(data.aiSettings);
      if (data.preferences) setPreferences(data.preferences);
    } catch (error) {
      toast.error('Failed to load settings');
      console.error('Error fetching settings:', error);
    } finally {
      setIsLoading(false);
    }
  };

  const handleApiKeyChange = (providerId: string, value: string) => {
    setApiKeys(prev => ({ ...prev, [providerId]: value }));
  };

  const handleAISettingsChange = (key: keyof AISettings, value: string | boolean) => {
    setAISettings(prev => ({ ...prev, [key]: value }));
  };

  const handlePreferencesChange = (key: keyof Preferences, value: 'light' | 'dark' | 'system') => {
    setPreferences(prev => ({ ...prev, [key]: value }));
  };

  const handleThemeChange = (value: 'light' | 'dark' | 'system') => {
    handlePreferencesChange('theme', value);
    setTheme(value);
  };

  const handleSave = async () => {
    setIsSaving(true);
    try {
      const baseUrl = window.wpAiAssistant.apiUrl.replace(/\/$/, ''); // Remove trailing slash if exists
      const response = await fetch(`${baseUrl}/wp-ai-assistant/v1/settings/save`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'X-WP-Nonce': window.wpAiAssistant.nonce
        },
        body: JSON.stringify({
          apiKeys,
          aiSettings,
          preferences
        }),
      });

      if (!response.ok) {
        throw new Error('Failed to save settings');
      }

      toast.success('Settings saved successfully');
    } catch (error) {
      toast.error('Failed to save settings');
      console.error('Error saving settings:', error);
    } finally {
      setIsSaving(false);
    }
  };

  if (isLoading) {
    return (
      <div className="min-h-screen bg-background py-8 flex items-center justify-center">
        <Loader2 className="h-8 w-8 animate-spin" />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background py-8">
      <div className="container mx-auto px-4 max-w-5xl">
        <div className="flex items-center justify-between mb-8">
          <div>
            <h1 className="text-2xl font-semibold flex items-center gap-2 text-foreground">
              <Settings className="h-6 w-6" />
              Settings
            </h1>
            <p className="text-sm text-muted-foreground mt-1">Manage your AI assistant configuration and preferences</p>
          </div>
          <Button onClick={handleSave} disabled={isSaving} size="lg" className="px-6">
            {isSaving ? (
              <>
                <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                Saving...
              </>
            ) : (
              <>
                <Save className="mr-2 h-4 w-4" />
                Save Changes
              </>
            )}
          </Button>
        </div>

        <Tabs defaultValue="api" className="space-y-6">
          <TabsList className="w-full justify-start bg-background border-b p-0 mb-6">
            <TabsTrigger value="api" className="flex items-center gap-2 rounded-none border-b-2 border-transparent data-[state=active]:border-primary data-[state=active]:bg-transparent px-4 pb-3">
              <Key className="h-4 w-4" />
              API Keys
            </TabsTrigger>
            <TabsTrigger value="ai" className="flex items-center gap-2 rounded-none border-b-2 border-transparent data-[state=active]:border-primary data-[state=active]:bg-transparent px-4 pb-3">
              <Bot className="h-4 w-4" />
              AI Settings
            </TabsTrigger>
            <TabsTrigger value="preferences" className="flex items-center gap-2 rounded-none border-b-2 border-transparent data-[state=active]:border-primary data-[state=active]:bg-transparent px-4 pb-3">
              <Settings className="h-4 w-4" />
              Preferences
            </TabsTrigger>
          </TabsList>

          <TabsContent value="api" className="space-y-6 mt-0">
            <Card className="border shadow-sm">
              <CardHeader className="border-b bg-muted/30">
                <CardTitle className="text-lg font-medium flex items-center gap-2">
                  <Key className="h-5 w-5" />
                  API Keys
                </CardTitle>
                <CardDescription className="text-sm">Enter your API keys for different AI providers</CardDescription>
              </CardHeader>
              <CardContent className="p-6 divide-y divide-border">
                {providers.map((provider) => (
                  <div key={provider.id} className="flex items-center gap-6 py-4 first:pt-0 last:pb-0">
                    <div className="w-12 h-12 flex items-center justify-center rounded-lg">
                      {provider.icon}
                    </div>
                    <div className="flex-1 min-w-0">
                      <Label className="text-sm font-medium block mb-2">{provider.name}</Label>
                      <div className="flex gap-3">
                        <Input
                          id={provider.id}
                          type="password"
                          value={apiKeys[provider.id] || ''}
                          onChange={(e: React.ChangeEvent<HTMLInputElement>) => handleApiKeyChange(provider.id, e.target.value)}
                          placeholder="Enter API key"
                          className="h-9 flex-1"
                        />
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => handleApiKeyChange(provider.id, '')}
                          className="flex items-center gap-2"
                        >
                          <Trash2 className="h-4 w-4" />
                          Clear
                        </Button>
                      </div>
                    </div>
                  </div>
                ))}
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="ai" className="space-y-6">
            <Card className="border-none shadow-none">
              <CardHeader className="px-0">
                <CardTitle className="text-xl font-semibold flex items-center gap-2">
                  <Sparkles className="h-5 w-5" />
                  AI Configuration
                </CardTitle>
                <CardDescription className="text-base">Configure your AI assistant settings</CardDescription>
              </CardHeader>
              <CardContent className="px-0 space-y-8">
                <div className="flex items-center justify-between">
                  <div className="space-y-1">
                    <Label className="text-base font-medium flex items-center gap-2">
                      <Bot className="h-4 w-4" />
                      Enable AI Agent
                    </Label>
                    <p className="text-sm text-muted-foreground">
                      Allow the AI to take actions on your behalf
                    </p>
                  </div>
                  <Switch
                    checked={aiSettings.enableAgent}
                    onCheckedChange={(checked: boolean) => handleAISettingsChange('enableAgent', checked)}
                  />
                </div>
                <div className="space-y-2">
                  <Label className="text-base font-medium flex items-center gap-2">
                    <MessageSquare className="h-4 w-4" />
                    System Prompt
                  </Label>
                  <Textarea
                    value={aiSettings.systemPrompt}
                    onChange={(e: React.ChangeEvent<HTMLTextAreaElement>) => handleAISettingsChange('systemPrompt', e.target.value)}
                    placeholder="Enter the system prompt for the AI"
                    className="min-h-[120px] resize-none"
                  />
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="preferences" className="space-y-6">
            <Card className="border-none shadow-none">
              <CardHeader className="px-0">
                <CardTitle className="text-xl font-semibold flex items-center gap-2">
                  <Settings className="h-5 w-5" />
                  Theme Settings
                </CardTitle>
                <CardDescription className="text-base">Customize your application appearance</CardDescription>
              </CardHeader>
              <CardContent className="px-0">
                <div className="space-y-4">
                  <div className="space-y-2">
                    <Label className="text-base font-medium flex items-center gap-2">
                      <Sun className="h-4 w-4" />
                      Theme
                    </Label>
                    <Select value={preferences.theme} onValueChange={handleThemeChange}>
                      <SelectTrigger>
                        <SelectValue placeholder="Select theme" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="light">Light</SelectItem>
                        <SelectItem value="dark">Dark</SelectItem>
                        <SelectItem value="system">System</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
      <Toaster position="top-center" />
    </div>
  );
};

export default SettingsPage; 