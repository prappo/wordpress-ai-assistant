export default function Info(){
    return <div>Info here</div>
}